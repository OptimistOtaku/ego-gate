# IEEE manuscript and evidence package

`main.tex` uses the official `IEEEtran` class in conference mode. No venue-specific page limit, affiliation, or author email was supplied. The author name is Aditya Singh. This is an author-review manuscript, not an accepted or peer-reviewed publication.

## Evidence status

- Completed evidence: archived `results/digits/` observations (20 paired training seeds, one fixed data split).
- Independently recalculated: table, confidence interval, paired statistic, effect size, and figure.
- Completed on Kaggle: 180 independent reproduction runs and 200 online admission/consolidation runs; raw evidence is under results/kaggle_ieee/ego_gate/.
- The private run completed, its source hashes match, and the 200-run budget/completeness audit passed.
- General intelligence, learned personality, poisoning defense, and a deployed agent-memory product remain hypotheses.

## Build

From the repository root:

```powershell
python scripts/prepare_ieee_assets.py
tectonic --keep-logs --outdir output/pdf paper/ieee/main.tex
```

Alternatively upload this directory to Overleaf and select `main.tex`. The standard IEEEtran class is required. The source package includes the computed table and vector figure. Do not use an arbitrary two-column template as a substitute.

## Kaggle

Configure credentials outside the repository in the standard Kaggle credential location. Never paste keys into a notebook or commit them.

```powershell
python scripts/prepare_kaggle.py --username YOUR_KAGGLE_USERNAME
.venv-paper/Scripts/python.exe -m kaggle kernels push -p kaggle
.venv-paper/Scripts/python.exe -m kaggle kernels status YOUR_KAGGLE_USERNAME/ego-gate-ieee-experiments
.venv-paper/Scripts/python.exe -m kaggle kernels output YOUR_KAGGLE_USERNAME/ego-gate-ieee-experiments -p results/kaggle_ieee
```

The notebook is PRIVATE and runs on CPU (small dense models and per-example scoring). Internet is used to download Fashion-MNIST. It writes raw trajectories, execution/source manifests and a completion marker. Kaggle quotas and runtime availability are account-dependent. The new study contains 200 runs: two datasets, two noise rates, five seeds, ten conditions. The independent reproduction contains 180 condition-seed runs. Both studies completed; the final manuscript reports positive and negative findings.

After downloading, locate `stream_results/raw.json` and run:

```powershell
python scripts/analyze_stream.py PATH_TO_STREAM_RESULTS
```

Do not overwrite archived results with the independent reproduction. Report discrepancies, failed runs, and package versions. Only update the manuscript after auditing complete results. Keep future evaluation labels and outcomes unavailable to the gate.

## Author review before submission

1. Select an IEEE venue and apply its page limit, anonymization, author metadata, and submission requirements.
2. Review all text, equations, references, and code, including AI-assisted additions.
3. Complete the new experiments, add stronger published baselines, and avoid treating statistical significance on one split as broad validation.
4. Publish the exact source version and evidence if desired; the current repository URL does not establish that these local additions have been pushed.
5. Preserve the AI assistance acknowledgment and adapt it to the venue's disclosure policy.

## Sources checked

- IEEE conference templates: https://conferences.ieeeauthorcenter.ieee.org/write-your-paper/authoring-tools-and-templates/
- IEEE AI disclosure: https://open.ieee.org/author-guidelines-for-artificial-intelligence-ai-generated-text/
- Kaggle CLI: https://github.com/Kaggle/kaggle-cli
- Kaggle kernel metadata: https://github.com/Kaggle/kaggle-cli/blob/main/docs/kernels_metadata.md
